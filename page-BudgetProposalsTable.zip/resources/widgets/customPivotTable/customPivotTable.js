(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customPivotTable', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope) {
// data source
  var data = $scope.properties.data;
 
  // pivot grid options
  var config = {
    dataSource: data,
    dataHeadersLocation: 'columns',
    theme: $scope.properties.theme,
    toolbar: {
        visible: $scope.properties.toolbar
    },
    grandTotal: {
        rowsvisible: true,
        columnsvisible: true
    },
    subTotal: {
        visible: true,
        collapsed: true
    },
    fields: $scope.properties.fields, /*[
        { name: '0', caption: 'Entity' },
        { name: '1', caption: 'Product' },
        { name: '2', caption: 'Manufacturer', sort: { order: 'asc' } },
        { name: '3', caption: 'Class' },
        { name: '4', caption: 'Category', sort: { order: 'desc' } },
        { name: '5', caption: 'Quantity' },
        {
            name: '6',
            caption: 'Amount',
            dataSettings: {
                  aggregateFunc: 'avg',
                  formatFunc: function(value) {
                      return Number(value).toFixed(0);
                  }
            }
        }
    ],*/
    rows    : $scope.properties.rows , //[ 'Manufacturer', 'Category' ],
    //columns : ['Class'],
    data    : [ 'Amount' ],
    /*preFilters : {
        'Manufacturer': { 'Matches': /n/ },
        'Amount'      : { '>':  40 }
    } */ //,
    width: 1110,
    height: 645
  };

  // instantiate and show the pivot grid
  new orb.pgridwidget(config).render(document.getElementById('pgrid'));
},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n \n<span ng-if="environment"><identicon name="{{environment.component.id}}" size="30" background-color="[255,255,255, 0]" foreground-color="[51,51,51]"></identicon> {{environment.component.name}}</span>\n<div id="pgrid"></div>'
    };
  });
